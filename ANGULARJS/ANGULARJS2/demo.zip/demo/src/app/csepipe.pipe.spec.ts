import { CsepipePipe } from './csepipe.pipe';

describe('CsepipePipe', () => {
  it('create an instance', () => {
    const pipe = new CsepipePipe();
    expect(pipe).toBeTruthy();
  });
});
