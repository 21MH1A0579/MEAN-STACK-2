import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CsepipePipe } from './csepipe.pipe';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,CommonModule,CsepipePipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  // show:boolean=false;
  // csevalue:string="meanstack";
//   users=[
//     {
//        name:"Durga",
//        branch:"CSE",
//        city:"Rjy",
//     },
//     {
//       name:"Prasad",
//       branch:"ECE",
//       city:"Kkd",
//    },
//    {
//     name:"YDP",
//     branch:"IT",
//     city:"KKd",
//  },
//  {
//   name:"Hemanth",
//   branch:"CSE",
//   city:"Vizag",
// },
// {
//   name:"Bhargav",
//   branch:"EEE",
//   city:"vzm",
// },
//   ]

//   itsme=7;

//   op:string="*";
//   n1:number=10;
//   n2:number=20;

//   csed:string="";


    name:string='mean stack';
    csedate=new Date();
    data:object={
      name:"YDP",
      branch:"CSE",
      city:"Rjy"
    }

    courses=["python","android","meanstack","jquery","java","cpp","c#","c","ai","php"]

    rocks:string="WELCOME TO MEANSTACK";




}
